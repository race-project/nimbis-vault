#!/bin/bash

export WORK_HOME=$PWD

export router_tool=qrouter
export migrate_tool=magic_db
export drc_tool=magic_drc
export lvs_tool=netgen_lvs
export gds_tool=magic_gds
export display_tool=klayout

LOG_FILE=run.log

clear
echo "Starting the execution of the open source Flow"
echo "----------------------------------------------"
echo "Output log will be saved into: $PWD/run.log"
echo ""

# blockchain session
echo -n "[Blackchain] Starting session"
SESSION_ID=`uuidgen`
cat << EOF > $PWD/.cc-create-session
{
  "inputs": {
    "assetId": "session-${SESSION_ID}",
    "flowId": "open-source-1.1",
    "toolId": "open-source-1.1",
    "userId": "${USER}",
    "versionTool": "1.1"
  }
}
EOF
aladdin start -c $HOME/.config.json $PWD/.cc-create-session &> $LOG_FILE
echo -e "\t\t[completed]"
echo ""

# Synthesis
echo -n "[1/5] Executing synthesis step"
qflow -p ${WORK_HOME} synthesize -T gscl45nm sync_mult &>> $LOG_FILE
echo -e "\t\t[completed]"

# Placement
echo -n "[2/5] Executing placement step"
qflow -p ${WORK_HOME} place -T gscl45nm sync_mult &>> $LOG_FILE
echo -e "\t\t[completed]"

# Router
echo -n "[3/5] Executing router step"
qflow -p ${WORK_HOME} route -T gscl45nm sync_mult &>> $LOG_FILE
echo -e "\t\t[completed]"

# Migrate, DRC, and LVS
echo -n "[4/5] Executing migrate, DRC, and LVS"
qflow -p ${WORK_HOME} migrate -T gscl45nm sync_mults &>> $LOG_FILE
# disabled # qflow -p ${WORK_HOME} drc -T gscl45nm sync_mult # do not enable
# disabled # qflow -p ${WORK_HOME} lvs -T gscl45nm sync_mult # do not enable
echo -e "\t[completed]"

# GDS Generation
echo -n "[5/5] Executing GDS generation"
qflow -p ${WORK_HOME} gdsii -T gscl45nm sync_mult &>> $LOG_FILE
echo -e "\t\t[completed]"
TIMESTAMP=`date -u +%FT%T,%3NZ`
cat << EOF > $PWD/.cc-transaction
{
  "inputs": {
    "assetId": "session-${SESSION_ID}",
    "dataType": "Input",
    "date": "$TIMESTAMP"
  }
}
EOF
echo -n "      [Blockchain] Storing transaction"
aladdin create -c $HOME/.config.json $PWD/.cc-transaction $PWD/layout/sync_mult.gds &>> $LOG_FILE
echo -e "\t[completed]"
echo ""

echo -n "[Blockchain] Finalizing session"
cat << EOF > $PWD/.cc-end-session
{
  "inputs": {
    "assetId": "session-${SESSION_ID}"
  }
}
EOF
aladdin end -c $HOME/.config.json $PWD/.cc-end-session &>> $LOG_FILE
echo -e "\t\t[completed]"

echo "----------------------------------------------"
echo "Flow execution successfully completed!"
echo ""
