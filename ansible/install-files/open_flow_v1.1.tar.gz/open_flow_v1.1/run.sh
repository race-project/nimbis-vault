#!/bin/bash

export WORK_HOME=$PWD

export router_tool=qrouter
export migrate_tool=magic_db
export drc_tool=magic_drc
export lvs_tool=netgen_lvs
export gds_tool=magic_gds
export display_tool=klayout

LOG_FILE=run.log

function storeTransaction {
  files=("$@")
  TIMESTAMP=`date -u +%FT%T,%3NZ`
  cat << EOF > $PWD/.cc-transaction
{
  "inputs": {
      "assetId": "session-${SESSION_ID}",
    "dataType": "Input",
    "date": "$TIMESTAMP"
    }
 }
EOF
  echo -ne "      [Blockchain] Storing transaction"
  for f in "${files[@]}"
  do
    echo -ne "\r      [Blockchain] Storing transaction: $f                     "
    aladdin create -c $HOME/.config.json $PWD/.cc-transaction $PWD/layout/$f &>> $LOG_FILE
  done
  echo -e "\r      [Blockchain] Storing transaction \t[\e[92mcompleted\e[39m]                          "
}

clear
echo "Starting the execution of the open source Flow"
echo "----------------------------------------------"
echo "Output log will be saved into: $PWD/run.log"
echo ""

# blockchain session
echo -n "[Blackchain] Starting session"
SESSION_ID=`uuidgen`
cat << EOF > $PWD/.cc-create-session
{
  "inputs": {
    "assetId": "session-${SESSION_ID}",
    "flowId": "open-source-1.1",
    "toolId": "open-source-1.1",
    "userId": "${USER}",
    "versionTool": "1.1"
  }
}
EOF
aladdin start -c $HOME/.config.json $PWD/.cc-create-session &> $LOG_FILE
echo -e "\t\t[\e[92mcompleted\e[39m]"
echo ""

# Synthesis
echo -n "[1/5] Executing synthesis step"
qflow -p ${WORK_HOME} synthesize -T gscl45nm sync_mult &>> $LOG_FILE
echo -e "\t\t[\e[92mcompleted\e[39m]"
files=("sync_mult.par")
storeTransaction "${files[@]}"

# Placement
echo -n "[2/5] Executing placement step"
qflow -p ${WORK_HOME} place -T gscl45nm sync_mult &>> $LOG_FILE
echo -e "\t\t[\e[92mcompleted\e[39m]"
files=("fillcells.txt" "sync_mult.cel" "sync_mult.cfg" "sync_mult.def" "sync_mult.info" "sync_mult.obs" "sync_mult.pin" "sync_mult.pl1" "sync_mult.pl2" "sync_mult_unroute.def")
storeTransaction "${files[@]}"

# Router
echo -n "[3/5] Executing router step"
qflow -p ${WORK_HOME} route -T gscl45nm sync_mult &>> $LOG_FILE
echo -e "\t\t[\e[92mcompleted\e[39m]"
files=("sync_mult.rc")
storeTransaction "${files[@]}"

# Migrate, DRC, and LVS
echo -n "[4/5] Executing migrate, DRC, and LVS"
qflow -p ${WORK_HOME} migrate -T gscl45nm sync_mults &>> $LOG_FILE
/usr/local/share/qflow/scripts/magic_db.sh ~/open_flow_v1.1 sync_mult &>> $LOG_FILE
# disabled # qflow -p ${WORK_HOME} drc -T gscl45nm sync_mult # do not enable
# disabled # qflow -p ${WORK_HOME} lvs -T gscl45nm sync_mult # do not enable
echo -e "\t[\e[92mcompleted\e[39m]"
files=("sync_mult.mag")
storeTransaction "${files[@]}"

# GDS Generation
echo -n "[5/5] Executing GDS generation"
qflow -p ${WORK_HOME} gdsii -T gscl45nm sync_mult &>> $LOG_FILE
echo -e "\t\t[\e[92mcompleted\e[39m]"
files=("sync_mult.gds")
storeTransaction "${files[@]}"

# Finalizing
echo -ne "\n[Blockchain] Finalizing session"
cat << EOF > $PWD/.cc-end-session
{
  "inputs": {
    "assetId": "session-${SESSION_ID}"
  }
}
EOF
aladdin end -c $HOME/.config.json $PWD/.cc-end-session &>> $LOG_FILE
echo -e "\t\t[\e[92mcompleted\e[39m]"

echo "----------------------------------------------"
echo "Flow execution successfully completed!"
echo ""
